﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Q22_Q25
{
    public partial class MobileWebForm : System.Web.UI.Page
    {
        string sqlcon = @"Data Source=.;Initial Catalog=XYZ;Integrated Security=True";
        string sqlcmd;
        SqlDataAdapter da;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
           
            sqlcmd = "select * from Mobile";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
            GridView2.DataSource = ds.Tables[0];
            GridView2.DataBind();
        }

        protected void btnAdd1_Click(object sender, EventArgs e)
        {
            sqlcmd = "insert into Mobile values (" + txtProductID.Text + ",'" + txtProductName.Text + "'," + txtUnitPrice.Text + "," + txtQuantity.Text + ",'" + txtCameraDetails.Text + "','" + txtMobileModel.Text + "','" + txtBatteryDetails.Text + "')";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        protected void btnUpdate1_Click(object sender, EventArgs e)
        {
            sqlcmd = "update Mobile set ProductId=" + txtProductID.Text + ",ProductName='" + txtProductName.Text + "', UnitPrice=" + txtUnitPrice.Text + ", Quantity=" + txtQuantity.Text + ",Camera Model=" + txtCameraDetails.Text + ",Mobile Model=" + txtMobileModel.Text + ",Battery Details=" + txtBatteryDetails.Text + " where ProductId=" + txtProductID.Text + "";

            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }

        protected void btnDelete1_Click(object sender, EventArgs e)
        {
            sqlcmd = "delete from  Mobile where ProductId=" + txtProductID.Text + "";
            ds = new DataSet();
            da = new SqlDataAdapter(sqlcmd, sqlcon);
            da.Fill(ds);
        }
    }
}